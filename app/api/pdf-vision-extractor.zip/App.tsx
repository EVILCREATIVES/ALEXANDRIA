import React, { useState, useCallback } from 'react';
import { AnalysisStatus, AnalyzedPage, VisualElement } from './types';
import { convertPdfToImages } from './services/pdfService';
import { detectVisualElements } from './services/geminiService';
import { cropImageFromBoundingBox } from './services/imageService';
import UploadZone from './components/UploadZone';
import ResultCard from './components/ResultCard';

const DEFAULT_PROMPT = `Analyze this document page. Detect all distinct visual elements such as charts, graphs, diagrams, photos, screenshots, or illustrations.

For each element:
1. Provide a Title and Description.
2. Accurately determine its bounding box [ymin, xmin, ymax, xmax] on a 0-1000 scale.

Ignore standard text paragraphs, headers, and footers. Only detect substantial visual content.`;

const App: React.FC = () => {
  const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.IDLE);
  const [pages, setPages] = useState<AnalyzedPage[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [model, setModel] = useState<string>('gemini-3-pro-preview');
  
  // Prompt State
  const [prompt, setPrompt] = useState<string>(DEFAULT_PROMPT);
  const [showSettings, setShowSettings] = useState(false);

  const handleFileSelect = useCallback(async (file: File) => {
    setStatus(AnalysisStatus.CONVERTING);
    setErrorMsg(null);
    setPages([]);

    try {
      // 1. Convert PDF to Images
      const images = await convertPdfToImages(file);
      
      if (images.length === 0) {
        throw new Error("No pages found in the PDF.");
      }

      // Initialize state
      const initialPages: AnalyzedPage[] = images.map((img, index) => ({
        id: `page-${index}-${Date.now()}`,
        pageNumber: index + 1,
        imageUrl: img,
        visualElements: [],
        loading: true,
      }));

      setPages(initialPages);
      setStatus(AnalysisStatus.ANALYZING);

      // 2. Analyze images in batches to avoid rate limits and memory issues
      const BATCH_SIZE = 3;
      
      for (let i = 0; i < initialPages.length; i += BATCH_SIZE) {
        const batch = initialPages.slice(i, i + BATCH_SIZE);
        
        await Promise.allSettled(batch.map(async (page) => {
          try {
            // A. Get Bounding Boxes from Gemini (using selected model and custom prompt)
            const detectedElements = await detectVisualElements(page.imageUrl, model, prompt);
            
            // B. Crop Images locally
            const processedElements: VisualElement[] = await Promise.all(
              detectedElements.map(async (el: any) => {
                const croppedUrl = await cropImageFromBoundingBox(page.imageUrl, el.box_2d);
                return {
                  title: el.title,
                  description: el.description,
                  box_2d: el.box_2d,
                  croppedImageUrl: croppedUrl
                };
              })
            );

            setPages(prev => prev.map(p => 
              p.pageNumber === page.pageNumber 
                ? { ...p, visualElements: processedElements, rawAnalysis: detectedElements, loading: false } 
                : p
            ));
          } catch (err) {
            console.error(`Error analyzing page ${page.pageNumber}`, err);
            setPages(prev => prev.map(p => 
              p.pageNumber === page.pageNumber 
                ? { ...p, loading: false } // Stop loading even if error
                : p
            ));
          }
        }));
      }

      setStatus(AnalysisStatus.COMPLETED);

    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.message || "An unexpected error occurred.");
      setStatus(AnalysisStatus.ERROR);
    }
  }, [model, prompt]);

  const resetApp = () => {
    setStatus(AnalysisStatus.IDLE);
    setPages([]);
    setErrorMsg(null);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-primary to-indigo-700 text-white w-10 h-10 rounded-lg flex items-center justify-center shadow-md">
              <i className="fa-solid fa-images text-lg"></i>
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-600 hidden sm:block">
              PDF Image Extractor
            </h1>
            <h1 className="text-xl font-bold text-gray-800 sm:hidden">
              PDF Vision
            </h1>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="relative hidden sm:block">
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                disabled={status === AnalysisStatus.ANALYZING || status === AnalysisStatus.CONVERTING}
                className="appearance-none bg-gray-100 border border-transparent text-sm rounded-lg py-2 pl-3 pr-8 font-medium text-gray-700 cursor-pointer hover:bg-gray-200 focus:ring-2 focus:ring-indigo-500 focus:bg-white outline-none disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <option value="gemini-3-pro-preview">Gemini 3 Pro</option>
                <option value="gemini-3-flash-preview">Gemini 3 Flash</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-gray-500">
                <i className="fa-solid fa-chevron-down text-xs"></i>
              </div>
            </div>

            <button
              onClick={() => setShowSettings(true)}
              className="p-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
              title="AI Settings"
            >
              <i className="fa-solid fa-gear text-lg"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow bg-gray-50 p-4 sm:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Intro Section */}
          {status === AnalysisStatus.IDLE && (
            <div className="text-center max-w-2xl mx-auto mt-10 mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Extract Visuals from PDFs
              </h2>
              <p className="text-gray-600 text-lg mb-6">
                Upload a PDF. We will detect charts, photos, and diagrams, crop them out, and describe them for you.
              </p>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-700 rounded-full text-sm font-medium border border-indigo-100">
                <i className="fa-solid fa-wand-magic-sparkles"></i>
                <span>Currently using: <strong>{model === 'gemini-3-pro-preview' ? 'Gemini 3 Pro' : 'Gemini 3 Flash'}</strong></span>
              </div>
            </div>
          )}

          {/* Upload Area */}
          {(status === AnalysisStatus.IDLE || status === AnalysisStatus.ERROR) && (
            <UploadZone 
              onFileSelected={handleFileSelect} 
              isProcessing={false} 
            />
          )}

          {/* Processing Indicator */}
          {status === AnalysisStatus.CONVERTING && (
             <div className="text-center py-20 animate-fade-in">
               <div className="inline-block p-4 rounded-full bg-indigo-50 mb-4">
                 <i className="fa-solid fa-file-pdf text-4xl text-indigo-500 animate-bounce"></i>
               </div>
               <h3 className="text-xl font-semibold text-gray-800">Reading PDF...</h3>
             </div>
          )}

          {/* Analysis Indicator */}
           {status === AnalysisStatus.ANALYZING && (
             <div className="text-center py-10 animate-fade-in">
               <div className="flex justify-center items-center gap-3 mb-4">
                  <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce delay-75"></div>
                  <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce delay-150"></div>
               </div>
               <h3 className="text-lg font-semibold text-gray-800">Analyzing with {model === 'gemini-3-pro-preview' ? 'Gemini 3 Pro' : 'Gemini 3 Flash'}...</h3>
               <p className="text-gray-500 text-sm mt-1">
                  Processing in batches. This might take a moment.
               </p>
             </div>
          )}

          {/* Error Message */}
          {status === AnalysisStatus.ERROR && errorMsg && (
            <div className="max-w-2xl mx-auto bg-red-50 border-l-4 border-red-500 p-4 rounded-md shadow-sm mb-8">
              <div className="flex items-center">
                <i className="fa-solid fa-circle-exclamation text-red-500 mr-3 text-xl"></i>
                <div>
                  <h3 className="text-red-800 font-medium">Processing Error</h3>
                  <p className="text-red-700 text-sm mt-1">{errorMsg}</p>
                </div>
              </div>
              <button 
                onClick={resetApp}
                className="mt-4 text-sm font-semibold text-red-600 hover:text-red-800 underline"
              >
                Try Another File
              </button>
            </div>
          )}

          {/* Results Grid */}
          {(status === AnalysisStatus.ANALYZING || status === AnalysisStatus.COMPLETED) && pages.length > 0 && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between pb-4 border-b border-gray-200">
                <h2 className="text-2xl font-bold text-gray-800">
                  Extracted Visuals <span className="text-gray-400 font-normal text-lg ml-2">({pages.length} Pages Processed)</span>
                </h2>
                <div className="flex gap-2">
                    <button 
                      onClick={resetApp}
                      className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 hover:text-gray-900 transition-colors shadow-sm text-sm font-medium"
                    >
                      <i className="fa-solid fa-arrow-rotate-left mr-2"></i>
                      Reset
                    </button>
                </div>
              </div>

              <div className="space-y-8">
                {pages.map((page) => (
                  <ResultCard key={page.id} page={page} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      
      {/* Settings Modal */}
      {showSettings && (
        <div 
          className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in"
          onClick={() => setShowSettings(false)}
        >
          <div 
            className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]"
            onClick={e => e.stopPropagation()}
          >
            <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-800">AI Extraction Rules</h3>
              <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-gray-600">
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <p className="text-sm text-gray-500 mb-4">
                These instructions guide Gemini on what to detect and how to extract it. Modify them to change the behavior (e.g., "Only extract charts").
              </p>
              
              <div className="mb-4">
                 <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-2">
                   System Prompt
                 </label>
                 <textarea
                   value={prompt}
                   onChange={(e) => setPrompt(e.target.value)}
                   className="w-full h-64 p-3 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-gray-800 bg-gray-50"
                 />
              </div>

              <div className="flex justify-end gap-2">
                 <button 
                   onClick={() => setPrompt(DEFAULT_PROMPT)}
                   className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800"
                 >
                   Reset to Default
                 </button>
                 <button 
                   onClick={() => setShowSettings(false)}
                   className="px-4 py-2 bg-indigo-600 text-white text-sm font-bold rounded-lg hover:bg-indigo-700 shadow-sm"
                 >
                   Save & Close
                 </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} PDF Vision Extractor. Uses Google Gemini API.
        </div>
      </footer>
    </div>
  );
};

export default App;