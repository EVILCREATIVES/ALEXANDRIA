import React, { useState } from 'react';
import { AnalyzedPage, VisualElement } from '../types';

interface ResultCardProps {
  page: AnalyzedPage;
}

const ResultCard: React.FC<ResultCardProps> = ({ page }) => {
  const [selectedImage, setSelectedImage] = useState<VisualElement | null>(null);
  const [showJson, setShowJson] = useState(false);

  // Filter out the heavy base64 strings for the JSON view so it's readable
  const getFormattedJson = () => {
    // If we have the raw output from Gemini (before local image cropping), use that.
    if (page.rawAnalysis) {
        return JSON.stringify(page.rawAnalysis, null, 2);
    }
    
    // Fallback: reconstruct data if raw is missing (legacy support)
    const cleanData = page.visualElements.map(el => ({
      title: el.title,
      description: el.description,
      box_2d: el.box_2d,
    }));
    return JSON.stringify(cleanData, null, 2);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Page Header */}
      <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center gap-4">
            <h3 className="font-bold text-gray-700">Page {page.pageNumber}</h3>
            {!page.loading && page.visualElements.length > 0 && (
                <button
                    onClick={() => setShowJson(!showJson)}
                    className="text-xs flex items-center gap-2 px-3 py-1.5 rounded-md bg-white border border-gray-200 text-gray-600 hover:text-indigo-600 hover:border-indigo-200 transition-all font-medium shadow-sm"
                    title={showJson ? "Switch to Visual View" : "View Raw JSON Data"}
                >
                    <i className={`fa-solid ${showJson ? 'fa-image' : 'fa-code'}`}></i>
                    {showJson ? 'View Visuals' : 'View JSON'}
                </button>
            )}
        </div>

        {page.loading ? (
            <span className="flex items-center text-indigo-600 text-sm font-medium animate-pulse">
                <i className="fa-solid fa-circle-notch fa-spin mr-2"></i> Scanning for visuals...
            </span>
        ) : (
            <span className="text-sm text-gray-500">
                {page.visualElements.length} Visuals Detected
            </span>
        )}
      </div>

      <div className="flex flex-col md:flex-row h-full min-h-[300px]">
        {/* Thumbnail of Original Page (Small reference) */}
        <div className="w-full md:w-48 bg-gray-100 p-4 border-b md:border-b-0 md:border-r border-gray-200 flex-shrink-0">
             <div className="relative group cursor-zoom-in aspect-[3/4]" onClick={() => setSelectedImage({ croppedImageUrl: page.imageUrl, title: `Full Page ${page.pageNumber}`, description: 'Original full page scan.', box_2d: [] })}>
                 <img 
                   src={page.imageUrl} 
                   alt={`Page ${page.pageNumber}`} 
                   className="w-full h-full object-contain shadow-sm rounded bg-white"
                 />
                 <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/50 transition-opacity rounded">
                    <span className="text-white text-xs font-bold">View Page</span>
                 </div>
             </div>
             <p className="text-center text-xs text-gray-400 mt-2">Original Page</p>
        </div>

        {/* Extracted Images Area or JSON View */}
        <div className="flex-grow p-6 relative">
            {showJson ? (
                <div className="absolute inset-0 m-4 rounded-lg overflow-hidden flex flex-col border border-gray-700 shadow-inner bg-gray-900">
                    <div className="px-4 py-2 bg-gray-800 border-b border-gray-700 flex justify-between items-center">
                        <span className="text-xs font-mono text-gray-400">extracted_data.json</span>
                        <button 
                            onClick={() => navigator.clipboard.writeText(getFormattedJson())} 
                            className="text-gray-400 hover:text-white text-xs flex items-center gap-1 transition-colors"
                        >
                            <i className="fa-regular fa-copy"></i> Copy
                        </button>
                    </div>
                    <pre className="p-4 text-xs font-mono text-green-400 overflow-auto flex-grow whitespace-pre-wrap">
                        {getFormattedJson()}
                    </pre>
                </div>
            ) : (
                <>
                    {!page.loading && page.visualElements.length === 0 && (
                        <div className="h-full flex flex-col items-center justify-center text-gray-400 py-8">
                            <i className="fa-regular fa-image text-4xl mb-2 opacity-50"></i>
                            <p>No images or charts detected on this page.</p>
                        </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        {page.visualElements.map((el, idx) => (
                            <div key={idx} className="group border border-gray-200 rounded-lg hover:shadow-lg transition-all duration-300 bg-white overflow-hidden flex flex-col">
                                <div 
                                   className="h-48 bg-gray-100 relative cursor-pointer overflow-hidden"
                                   onClick={() => setSelectedImage(el)}
                                >
                                    <img 
                                        src={el.croppedImageUrl} 
                                        alt={el.title} 
                                        className="w-full h-full object-contain p-2 group-hover:scale-105 transition-transform duration-300"
                                    />
                                </div>
                                <div className="p-4 flex-grow flex flex-col">
                                    <h4 className="font-bold text-gray-800 mb-1 line-clamp-1" title={el.title}>{el.title}</h4>
                                    <p className="text-sm text-gray-600 line-clamp-3 mb-2 flex-grow" title={el.description}>
                                        {el.description}
                                    </p>
                                    <button 
                                        onClick={() => setSelectedImage(el)}
                                        className="text-indigo-600 text-xs font-semibold uppercase tracking-wide mt-auto hover:text-indigo-800 text-left"
                                    >
                                        View Details &rarr;
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </>
            )}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in"
          onClick={() => setSelectedImage(null)}
        >
          <div 
            className="relative max-w-6xl w-full max-h-[90vh] flex flex-col md:flex-row bg-white rounded-xl overflow-hidden shadow-2xl" 
            onClick={(e) => e.stopPropagation()}
          >
             <div className="flex-grow bg-black flex items-center justify-center p-4 relative h-[50vh] md:h-auto">
                 <img 
                    src={selectedImage.croppedImageUrl} 
                    alt={selectedImage.title} 
                    className="max-w-full max-h-full object-contain"
                 />
             </div>
             <div className="md:w-96 bg-white p-8 flex flex-col overflow-y-auto">
                 <div className="flex justify-between items-start mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">{selectedImage.title}</h2>
                    <button onClick={() => setSelectedImage(null)} className="text-gray-400 hover:text-gray-600">
                        <i className="fa-solid fa-xmark text-2xl"></i>
                    </button>
                 </div>
                 
                 <div className="prose prose-sm prose-indigo text-gray-600">
                     <h3 className="text-sm uppercase tracking-wide text-gray-400 font-bold mb-2">AI Analysis</h3>
                     <p className="whitespace-pre-wrap">{selectedImage.description}</p>
                     
                     {selectedImage.box_2d.length > 0 && (
                        <>
                           <h3 className="text-sm uppercase tracking-wide text-gray-400 font-bold mb-2 mt-4">Bounding Box</h3>
                           <p className="font-mono text-xs bg-gray-100 p-2 rounded">
                             [{selectedImage.box_2d.join(', ')}]
                           </p>
                        </>
                     )}
                 </div>

                 <div className="mt-auto pt-8">
                     <a 
                       href={selectedImage.croppedImageUrl} 
                       download={`${selectedImage.title.replace(/\s+/g, '_')}.jpg`}
                       className="block w-full py-3 bg-indigo-600 text-white font-bold text-center rounded-lg hover:bg-indigo-700 transition-colors shadow-md"
                     >
                       <i className="fa-solid fa-download mr-2"></i> Download Image
                     </a>
                 </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResultCard;