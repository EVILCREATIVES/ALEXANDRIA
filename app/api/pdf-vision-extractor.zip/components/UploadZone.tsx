import React, { ChangeEvent } from 'react';

interface UploadZoneProps {
  onFileSelected: (file: File) => void;
  isProcessing: boolean;
}

const UploadZone: React.FC<UploadZoneProps> = ({ onFileSelected, isProcessing }) => {
  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelected(e.target.files[0]);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto mb-8">
      <div className="relative border-2 border-dashed border-gray-300 rounded-xl bg-white hover:bg-gray-50 transition-colors duration-300 ease-in-out p-12 text-center group">
        <input
          type="file"
          accept=".pdf"
          onChange={handleInputChange}
          disabled={isProcessing}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10 disabled:cursor-not-allowed"
        />
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="p-4 bg-indigo-50 text-indigo-600 rounded-full group-hover:scale-110 transition-transform duration-300">
            <i className="fa-solid fa-file-pdf text-4xl"></i>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-700">
              {isProcessing ? 'Processing Document...' : 'Upload PDF Document'}
            </h3>
            <p className="text-gray-500 mt-2 text-sm">
              Click or drag a PDF here to extract and analyze images.
            </p>
          </div>
          {!isProcessing && (
            <button className="px-6 py-2 bg-primary text-white rounded-lg shadow-md hover:bg-indigo-700 transition-colors pointer-events-none">
              Select File
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default UploadZone;