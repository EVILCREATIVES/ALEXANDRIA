import { GoogleGenAI, Type } from "@google/genai";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Define the response schema for structured extraction
const analysisSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: { 
        type: Type.STRING, 
        description: "A concise title for the visual element (e.g., 'Bar Chart of Sales', 'Photo of Device')." 
      },
      description: { 
        type: Type.STRING, 
        description: "A detailed description of the visual content, data trends, or objects visible." 
      },
      box_2d: {
        type: Type.ARRAY,
        description: "Bounding box coordinates [ymin, xmin, ymax, xmax] normalized to a 0-1000 scale.",
        items: { type: Type.INTEGER }
      }
    },
    required: ["title", "description", "box_2d"]
  }
};

/**
 * Analyzes an image to detect visual elements and their bounding boxes.
 * @param base64DataUrl The image data
 * @param modelName The specific Gemini model to use
 * @param customPrompt The instructions for the AI
 */
export const detectVisualElements = async (base64DataUrl: string, modelName: string, customPrompt: string): Promise<any[]> => {
  try {
    const base64Data = base64DataUrl.split(',')[1];
    
    if (!base64Data) {
      throw new Error("Invalid image data");
    }

    const response = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Data
            }
          },
          {
            text: customPrompt
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: analysisSchema
      }
    });

    // Parse the JSON response
    const result = JSON.parse(response.text || "[]");
    return result;

  } catch (error) {
    console.error("Gemini API Error:", error);
    // Return empty array on error to prevent app crash
    return [];
  }
};