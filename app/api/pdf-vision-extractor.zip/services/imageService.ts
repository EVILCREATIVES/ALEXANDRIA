/**
 * Crops a specific region from a base64 image string based on bounding box coordinates.
 * 
 * @param sourceBase64 The full page image as a base64 string
 * @param box_2d [ymin, xmin, ymax, xmax] on a 0-1000 scale
 * @returns Promise resolving to the cropped image as a base64 string
 */
export const cropImageFromBoundingBox = async (
  sourceBase64: string, 
  box_2d: number[]
): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!box_2d || box_2d.length !== 4) {
      resolve(sourceBase64); // Fallback to original if invalid box
      return;
    }

    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error("Could not create canvas context"));
        return;
      }

      // Deconstruct normalized coordinates (0-1000 scale)
      const [ymin, xmin, ymax, xmax] = box_2d;

      // Calculate pixel values
      // Note: ymin/ymax are relative to height, xmin/xmax relative to width
      const y = (ymin / 1000) * img.height;
      const x = (xmin / 1000) * img.width;
      const h = ((ymax - ymin) / 1000) * img.height;
      const w = ((xmax - xmin) / 1000) * img.width;

      // Add a small padding (margin) to the crop to ensure borders aren't cut off
      const padding = 10; 
      const safeX = Math.max(0, x - padding);
      const safeY = Math.max(0, y - padding);
      const safeW = Math.min(img.width - safeX, w + (padding * 2));
      const safeH = Math.min(img.height - safeY, h + (padding * 2));

      canvas.width = safeW;
      canvas.height = safeH;

      // Draw the cropped portion
      ctx.drawImage(img, safeX, safeY, safeW, safeH, 0, 0, safeW, safeH);

      resolve(canvas.toDataURL('image/jpeg', 0.9));
    };
    
    img.onerror = () => reject(new Error("Failed to load source image for cropping"));
    img.src = sourceBase64;
  });
};