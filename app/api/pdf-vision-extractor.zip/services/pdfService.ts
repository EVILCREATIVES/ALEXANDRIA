import { getDocument, GlobalWorkerOptions, version } from 'pdfjs-dist';

// Setting up the worker. 
// We use the version exported from the library to ensure compatibility.
GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${version}/build/pdf.worker.min.mjs`;

/**
 * Reads a file as an ArrayBuffer
 */
const readFileAsArrayBuffer = (file: File): Promise<ArrayBuffer> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as ArrayBuffer);
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
};

/**
 * Converts a PDF file into an array of Base64 image strings (one per page).
 */
export const convertPdfToImages = async (file: File): Promise<string[]> => {
  try {
    const data = await readFileAsArrayBuffer(file);
    
    // Use getDocument directly from named import
    const loadingTask = getDocument({ data });
    const pdf = await loadingTask.promise;
    
    const pageImages: string[] = [];
    const totalPages = pdf.numPages;

    // Limit to first 25 pages as requested
    const pagesToProcess = Math.min(totalPages, 25);

    for (let pageNum = 1; pageNum <= pagesToProcess; pageNum++) {
      const page = await pdf.getPage(pageNum);
      
      // Dynamic scaling: If processing many pages, reduce scale slightly to prevent 
      // browser memory exhaustion (OOM) while maintaining readability for the AI.
      const scale = pagesToProcess > 10 ? 1.2 : 1.5;
      
      const viewport = page.getViewport({ scale });
      
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      if (!context) {
        throw new Error('Could not create canvas context');
      }

      canvas.height = viewport.height;
      canvas.width = viewport.width;

      const renderContext = {
        canvasContext: context,
        viewport: viewport,
      };

      // Cast to any to avoid type mismatch with stricter RenderParameters definition
      // which might incorrectly require a 'canvas' property in some type versions.
      await page.render(renderContext as any).promise;
      
      // Convert to JPEG with 0.85 quality to save size compared to PNG
      const imageUrl = canvas.toDataURL('image/jpeg', 0.85);
      pageImages.push(imageUrl);
    }

    return pageImages;
  } catch (error) {
    console.error('Error processing PDF:', error);
    throw new Error('Failed to process PDF file. Please ensure it is a valid PDF.');
  }
};