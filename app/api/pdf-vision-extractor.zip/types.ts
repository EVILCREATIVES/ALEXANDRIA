export enum AnalysisStatus {
  IDLE = 'IDLE',
  CONVERTING = 'CONVERTING',
  ANALYZING = 'ANALYZING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface VisualElement {
  title: string;
  description: string;
  box_2d: number[]; // [ymin, xmin, ymax, xmax] on 0-1000 scale
  croppedImageUrl?: string; // The extracted image base64
}

export interface AnalyzedPage {
  id: string;
  pageNumber: number;
  imageUrl: string; // Full page Base64
  visualElements: VisualElement[];
  loading: boolean;
  rawAnalysis?: any; // The raw JSON output from Gemini before local processing
}

export interface PDFData {
  fileName: string;
  pageCount: number;
}